# Zoon Tomsk restaurants parcer

Парсер ресторанов Томска с https://zoon.ru/tomsk/restaurants/

## Установка
```bash
pip install zoon-tomsk-restaurants-parser
```
## Использование
```python
from zoon_tomsk_restaurants_parcer import parse_all_restaurants_to_csv

parse_all_restaurants_to_csv()